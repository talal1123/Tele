import React, { useState } from 'react';
import { BuyForm } from './components/BuyForm';
import { SellForm } from './components/SellForm';
import { MessageCircle, TrendingUp, ArrowRightLeft } from 'lucide-react';
import { Logo } from './components/Logo';
import { useLanguage } from './contexts/LanguageContext';
import { LanguageToggle } from './components/LanguageToggle';

function App() {
  const [operation, setOperation] = useState<'buy' | 'sell'>('buy');
  const { t, language } = useLanguage();

  return (
    <div className="min-h-screen bg-gradient-to-br from-secondary-900 via-secondary-800 to-secondary-900" dir={language === 'ar' ? 'rtl' : 'ltr'}>
      <div className="container mx-auto px-4 py-8 md:py-16">
        {/* Header Card */}
        <div className="max-w-3xl mx-auto mb-6 bg-secondary-800/50 backdrop-blur-sm rounded-2xl shadow-lg p-6 border border-primary-400/10">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="relative">
                <div className="absolute inset-0 bg-primary-400/20 rounded-xl blur-xl"></div>
                <div className="relative bg-gradient-to-br from-primary-400 to-primary-500 p-3 rounded-xl">
                  <Logo className="w-8 h-8 text-primary-400" />
                </div>
              </div>
              <div>
                <h1 className="text-3xl font-bold bg-gradient-to-r from-primary-400 to-primary-300 bg-clip-text text-transparent">
                  Telepayz
                </h1>
                <p className="text-primary-400/80 mt-1 flex items-center gap-2">
                  <TrendingUp size={16} className="text-primary-400/60" />
                  {language === 'ar' ? 'تبادل USDT سريع وآمن' : 'Fast & Secure USDT Exchange'}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <LanguageToggle />
              <a
                href="https://t.me/telepayzadmin"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 bg-primary-400/10 hover:bg-primary-400/20 text-primary-400 px-6 py-3 rounded-xl transition-all duration-300 hover:scale-105 group"
              >
                <MessageCircle size={20} className="group-hover:rotate-12 transition-transform" />
                <span>{language === 'ar' ? 'اتصل بالدعم' : 'Contact Support'}</span>
              </a>
            </div>
          </div>
        </div>

        {/* Main Card */}
        <div className="max-w-3xl mx-auto bg-secondary-800/50 backdrop-blur-sm rounded-2xl shadow-lg p-6 md:p-8 border border-primary-400/10">
          {/* Operation Toggle */}
          <div className="grid grid-cols-2 gap-4 mb-8 p-1.5 bg-secondary-700/50 rounded-xl">
            <button
              onClick={() => setOperation('buy')}
              className={`py-3 px-4 rounded-lg font-medium transition-all duration-300 flex items-center justify-center gap-2 ${
                operation === 'buy'
                  ? 'bg-primary-400 text-secondary-900 shadow-lg scale-100'
                  : 'bg-transparent text-primary-400 hover:bg-primary-400/10 scale-95'
              }`}
            >
              <ArrowRightLeft size={18} className={operation === 'buy' ? 'rotate-0' : '-rotate-12'} />
              {t('buy.title')}
            </button>
            <button
              onClick={() => setOperation('sell')}
              className={`py-3 px-4 rounded-lg font-medium transition-all duration-300 flex items-center justify-center gap-2 ${
                operation === 'sell'
                  ? 'bg-primary-400 text-secondary-900 shadow-lg scale-100'
                  : 'bg-transparent text-primary-400 hover:bg-primary-400/10 scale-95'
              }`}
            >
              <ArrowRightLeft size={18} className={operation === 'sell' ? 'rotate-0' : 'rotate-12'} />
              {t('sell.title')}
            </button>
          </div>

          {/* Forms */}
          <div className="transition-all duration-300">
            {operation === 'buy' ? <BuyForm /> : <SellForm />}
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;