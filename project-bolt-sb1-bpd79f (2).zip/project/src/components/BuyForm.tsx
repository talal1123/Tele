import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { FormField } from './FormField';
import { SelectField } from './SelectField';
import { NetworkFeeNotice } from './NetworkFeeNotice';
import { ArrowRightLeft, AlertCircle, CheckCircle2, Loader2, Calculator } from 'lucide-react';
import { submitBuyOrder, calculateBuyAmount } from '../services/buyService';
import { useLanguage } from '../contexts/LanguageContext';
import type { BuyOrder } from '../types/orders';

const buyFormSchema = z.object({
  amount: z.string()
    .min(1, 'Amount is required')
    .refine((val) => parseFloat(val) >= 5, 'Minimum amount is 5 USD'),
  network: z.enum(['trc20', 'bep20']),
  walletAddress: z.string().min(1, 'Wallet address is required'),
  email: z.string().email('Invalid email address'),
});

interface StatusMessage {
  type: 'success' | 'error';
  text: string;
}

export const BuyForm = () => {
  const [status, setStatus] = useState<StatusMessage | null>(null);
  const [receivedAmount, setReceivedAmount] = useState<number>(0);
  const { t } = useLanguage();
  
  const {
    register,
    handleSubmit,
    watch,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<BuyOrder>({
    resolver: zodResolver(buyFormSchema),
    defaultValues: {
      network: 'trc20',
    }
  });

  const amount = watch('amount');
  const network = watch('network');

  useEffect(() => {
    const numAmount = parseFloat(amount || '0');
    setReceivedAmount(calculateBuyAmount(numAmount));
  }, [amount]);

  const onSubmit = async (data: BuyOrder) => {
    try {
      setStatus(null);
      await submitBuyOrder({
        ...data,
        receivedAmount: receivedAmount.toString(),
      });
      setStatus({
        type: 'success',
        text: t('buy.successMessage'),
      });
      reset();
    } catch (error) {
      setStatus({
        type: 'error',
        text: error instanceof Error ? error.message : t('common.errorMessage'),
      });
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="w-full">
      {status && (
        <div className={`mb-6 p-4 rounded-lg flex items-start gap-3 ${
          status.type === 'success' ? 'bg-emerald-400/10 text-emerald-400' : 'bg-red-500/10 text-red-400'
        }`}>
          {status.type === 'success' ? (
            <CheckCircle2 className="w-5 h-5 mt-0.5 flex-shrink-0" />
          ) : (
            <AlertCircle className="w-5 h-5 mt-0.5 flex-shrink-0" />
          )}
          <p className="text-sm">{status.text}</p>
        </div>
      )}

      <div className="relative">
        <FormField
          label={t('common.amount')}
          name="amount"
          type="number"
          min="5"
          step="any"
          register={register}
          errors={errors}
          placeholder={t('common.enterAmount')}
          className="bg-emerald-400/5 border-emerald-400/20 focus:border-emerald-400 focus:ring-emerald-400"
        />
        {amount && parseFloat(amount) >= 5 && (
          <div className="mt-2 flex items-center gap-2 text-emerald-400">
            <Calculator size={16} />
            <span className="text-sm">
              {t('common.youWillReceive')}: {receivedAmount.toFixed(2)} USDT ({t('common.feeIncluded')})
            </span>
          </div>
        )}
      </div>

      <div className="bg-emerald-400/10 p-4 rounded-lg mb-6">
        <p className="text-emerald-400">
          Payment available via PayPal only: <strong>tala.sala94@gmail.com</strong>
        </p>
      </div>

      <div className="space-y-4">
        <FormField
          label="Your Wallet Address"
          name="walletAddress"
          register={register}
          errors={errors}
          placeholder="Enter your wallet address"
          className="bg-emerald-400/5 border-emerald-400/20 focus:border-emerald-400 focus:ring-emerald-400"
        />

        <SelectField
          label="Network"
          name="network"
          register={register}
          errors={errors}
          options={[
            { value: 'trc20', label: 'TRC20' },
            { value: 'bep20', label: 'BEP20' },
          ]}
          className="bg-emerald-400/5 border-emerald-400/20 focus:border-emerald-400 focus:ring-emerald-400"
        />

        {network === 'trc20' && <NetworkFeeNotice network={network} theme="buy" />}

        <FormField
          label="Your Email"
          name="email"
          type="email"
          register={register}
          errors={errors}
          placeholder="Enter your PayPal email"
          className="bg-emerald-400/5 border-emerald-400/20 focus:border-emerald-400 focus:ring-emerald-400"
        />
      </div>

      <button
        type="submit"
        disabled={isSubmitting}
        className="w-full bg-emerald-400 hover:bg-emerald-500 text-secondary-900 font-medium py-3 px-4 rounded-lg transition-colors flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed mt-6"
      >
        {isSubmitting ? (
          <>
            <Loader2 className="w-5 h-5 animate-spin" />
            <span>Processing...</span>
          </>
        ) : (
          <>
            <ArrowRightLeft size={20} />
            <span>Buy USDT</span>
          </>
        )}
      </button>
    </form>
  );
};