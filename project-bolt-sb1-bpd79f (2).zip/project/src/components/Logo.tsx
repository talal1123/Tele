import React from 'react';

export const Logo: React.FC<{ className?: string }> = ({ className = "w-8 h-8" }) => {
  return (
    <svg 
      viewBox="0 0 24 24" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      <circle cx="12" cy="12" r="12" className="fill-current" />
      <path
        d="M12 4v2m0 12v2M8 12h8"
        stroke="currentColor"
        strokeOpacity="0.2"
        strokeWidth="3"
        strokeLinecap="round"
        className="stroke-secondary-900"
      />
      <path
        d="M12 7v10"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        className="stroke-secondary-900"
      />
    </svg>
  );
};