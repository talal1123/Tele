import React from 'react';
import { UseFormRegister, FieldValues, FieldErrors } from 'react-hook-form';

interface Option {
  value: string;
  label: string;
}

interface SelectFieldProps {
  label: string;
  name: string;
  register: UseFormRegister<FieldValues>;
  errors: FieldErrors;
  options: Option[];
  className?: string;
}

export const SelectField: React.FC<SelectFieldProps> = ({
  label,
  name,
  register,
  errors,
  options,
  className,
}) => {
  return (
    <div className="mb-4">
      <label htmlFor={name} className="block text-sm font-medium mb-1.5">
        {label}
      </label>
      <select
        {...register(name)}
        id={name}
        className={`w-full px-4 py-3 rounded-xl focus:ring-2 transition-colors ${className}`}
      >
        <option value="">Select {label}</option>
        {options.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
      {errors[name] && (
        <p className="mt-2 text-sm text-red-400 flex items-center gap-1">
          <span className="inline-block w-1 h-1 bg-red-400 rounded-full"></span>
          {errors[name]?.message as string}
        </p>
      )}
    </div>
  );
};