<template>
  <Page>
    <ActionBar title="Telepayz" flat="true">
      <NavigationButton visibility="collapsed" />
      <ActionItem 
        ios.position="right" 
        android.position="right"
        @tap="openTelegram"
      >
        <Label text="Support" class="action-label" />
      </ActionItem>
    </ActionBar>

    <ScrollView>
      <StackLayout class="p-4">
        <!-- Header -->
        <GridLayout rows="auto" columns="auto, *" class="header m-b-4">
          <Image src="~/assets/logo.png" width="40" height="40" class="logo" col="0" />
          <StackLayout col="1" class="m-l-4">
            <Label text="Telepayz" class="title" />
            <Label text="Fast & Secure USDT Exchange" class="subtitle" />
          </StackLayout>
        </GridLayout>

        <!-- Operation Toggle -->
        <GridLayout rows="auto" columns="*, *" class="operation-toggle m-b-4">
          <Button 
            text="Buy USDT" 
            :class="operation === 'buy' ? 'btn-active' : 'btn-inactive'" 
            @tap="operation = 'buy'" 
            col="0" 
          />
          <Button 
            text="Sell USDT" 
            :class="operation === 'sell' ? 'btn-active' : 'btn-inactive'" 
            @tap="operation = 'sell'" 
            col="1" 
          />
        </GridLayout>

        <!-- Forms -->
        <BuyForm v-if="operation === 'buy'" />
        <SellForm v-else />
      </StackLayout>
    </ScrollView>
  </Page>
</template>

<script>
import { openUrl } from '@nativescript/core';
import BuyForm from './BuyForm.vue';
import SellForm from './SellForm.vue';

export default {
  name: 'Home',
  components: {
    BuyForm,
    SellForm
  },
  data() {
    return {
      operation: 'buy'
    };
  },
  methods: {
    openTelegram() {
      openUrl('https://t.me/telepayzadmin');
    }
  }
};
</script>

<style lang="scss" scoped>
.header {
  background-color: rgba(251, 191, 36, 0.1);
  border-radius: 12;
  padding: 16;
}

.title {
  font-size: 24;
  font-weight: bold;
  color: #fbbf24;
}

.subtitle {
  font-size: 14;
  color: rgba(251, 191, 36, 0.8);
}

.operation-toggle {
  background-color: rgba(251, 191, 36, 0.1);
  border-radius: 12;
  padding: 4;
}

.btn-active {
  background-color: #fbbf24;
  color: #1e293b;
  font-weight: bold;
  border-radius: 8;
}

.btn-inactive {
  background-color: transparent;
  color: #fbbf24;
  font-weight: bold;
  border-radius: 8;
}

.action-label {
  color: #fbbf24;
  font-size: 16;
  padding: 8 16;
}
</style>