<content><template>
  <StackLayout class="payment-details">
    <!-- Country Selection -->
    <StackLayout class="input-group">
      <Label text="Country" class="label" />
      <DropDown
        :items="countries"
        v-model="details.country"
        class="dropdown"
        @selectedIndexChanged="onCountryChange"
      />
    </StackLayout>

    <StackLayout v-if="details.country" class="details-form">
      <!-- Bank Details -->
      <StackLayout v-if="method === 'bank'">
        <StackLayout class="input-group">
          <Label text="Bank Name" class="label" />
          <DropDown
            :items="serviceOptions"
            v-model="details.bankName"
            class="dropdown"
          />
        </StackLayout>
        <StackLayout class="input-group">
          <Label text="Account Number" class="label" />
          <TextField
            v-model="details.accountNumber"
            class="input"
            hint="Enter account number"
          />
        </StackLayout>
        <StackLayout class="input-group">
          <Label text="Full Name" class="label" />
          <TextField
            v-model="details.fullName"
            class="input"
            hint="Enter account holder's name"
          />
        </StackLayout>
        <StackLayout class="input-group">
          <Label text="Address" class="label" />
          <TextField
            v-model="details.address"
            class="input"
            hint="Enter your address"
          />
        </StackLayout>
      </StackLayout>

      <!-- Transfer Details -->
      <StackLayout v-if="method === 'transfer'">
        <StackLayout class="input-group">
          <Label text="Transfer Company" class="label" />
          <DropDown
            :items="serviceOptions"
            v-model="details.company"
            class="dropdown"
          />
        </StackLayout>
        <StackLayout class="input-group">
          <Label text="Full Name" class="label" />
          <TextField
            v-model="details.fullName"
            class="input"
            hint="Enter recipient's name"
          />
        </StackLayout>
        <StackLayout class="input-group">
          <Label text="Phone Number" class="label" />
          <TextField
            v-model="details.phoneNumber"
            keyboardType="phone"
            class="input"
            hint="Enter phone number"
          />
        </StackLayout>
        <StackLayout class="input-group">
          <Label text="Address" class="label" />
          <TextField
            v-model="details.address"
            class="input"
            hint="Enter your address"
          />
        </StackLayout>
      </StackLayout>

      <!-- Cash Details -->
      <StackLayout v-if="method === 'cash'">
        <StackLayout class="input-group">
          <Label text="Cash Provider" class="label" />
          <DropDown
            :items="serviceOptions"
            v-model="details.provider"
            class="dropdown"
          />
        </StackLayout>
        <StackLayout class="input-group">
          <Label text="Full Name" class="label" />
          <TextField
            v-model="details.fullName"
            class="input"
            hint="Enter your name"
          />
        </StackLayout>
        <StackLayout class="input-group">
          <Label text="Phone Number" class="label" />
          <TextField
            v-model="details.phoneNumber"
            keyboardType="phone"
            class="input"
            hint="Enter phone number"
          />
        </StackLayout>
      </StackLayout>
    </StackLayout>
  </StackLayout>
</template>

<script>
import { countryData } from '../data/countries';

export default {
  name: 'PaymentDetails',
  props: {
    method: {
      type: String,
      required: true
    }
  },
  data() {
    return {
      details: {},
      countries: Object.keys(countryData[this.method]).map(country => ({
        value: country,
        text: country
      })),
      serviceOptions: []
    };
  },
  watch: {
    details: {
      deep: true,
      handler(newValue) {
        this.$emit('update', newValue);
      }
    }
  },
  methods: {
    onCountryChange(event) {
      const country = this.countries[event.value].value;
      this.serviceOptions = countryData[this.method][country].map(service => ({
        value: service,
        text: service
      }));
    }
  }
};
</script>

<style lang="scss" scoped>
.payment-details {
  background-color: rgba(251, 191, 36, 0.05);
  border-radius: 8;
  padding: 16;
  margin-bottom: 16;
}

.input-group {
  margin-bottom: 16;
}

.label {
  color: #fbbf24;
  font-size: 14;
  margin-bottom: 4;
}

.input {
  background-color: rgba(251, 191, 36, 0.1);
  border-width: 1;
  border-color: rgba(251, 191, 36, 0.3);
  border-radius: 8;
  padding: 12;
  color: #fbbf24;
}

.dropdown {
  background-color: rgba(251, 191, 36, 0.1);
  border-width: 1;
  border-color: rgba(251, 191, 36, 0.3);
  border-radius: 8;
  padding: 12;
  color: #fbbf24;
}

.details-form {
  margin-top: 16;
}
</style></content>