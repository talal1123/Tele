<content><template>
  <StackLayout class="form">
    <!-- Status Message -->
    <StackLayout v-if="status" :class="['status-message', status.type]">
      <Label :text="status.text" textWrap="true" />
    </StackLayout>

    <!-- Amount Input -->
    <StackLayout class="input-group">
      <Label text="Amount (USDT)" class="label" />
      <TextField
        v-model="formData.amount"
        keyboardType="number"
        class="input"
        hint="Enter amount"
      />
      <Label v-if="errors.amount" :text="errors.amount" class="error" />
    </StackLayout>

    <!-- Payment Info -->
    <StackLayout class="info-box">
      <Label text="Payment via PayPal only:" class="info-label" />
      <Label text="tala.sala94@gmail.com" class="info-value" />
    </StackLayout>

    <!-- Wallet Address -->
    <StackLayout class="input-group">
      <Label text="Your Wallet Address" class="label" />
      <TextField
        v-model="formData.walletAddress"
        class="input"
        hint="Enter your wallet address"
      />
      <Label v-if="errors.walletAddress" :text="errors.walletAddress" class="error" />
    </StackLayout>

    <!-- Network Selection -->
    <StackLayout class="input-group">
      <Label text="Network" class="label" />
      <DropDown
        :items="networks"
        v-model="formData.network"
        class="dropdown"
      />
      <Label v-if="errors.network" :text="errors.network" class="error" />
    </StackLayout>

    <!-- Email -->
    <StackLayout class="input-group">
      <Label text="Your Email" class="label" />
      <TextField
        v-model="formData.email"
        keyboardType="email"
        class="input"
        hint="Enter your PayPal email"
      />
      <Label v-if="errors.email" :text="errors.email" class="error" />
    </StackLayout>

    <!-- Submit Button -->
    <Button
      :text="isSubmitting ? 'Processing...' : 'Buy USDT'"
      @tap="onSubmit"
      :isEnabled="!isSubmitting"
      class="submit-button"
    />
  </StackLayout>
</template>

<script>
import { submitExchangeRequest } from '../services/api';

export default {
  name: 'BuyForm',
  data() {
    return {
      formData: {
        operation: 'buy',
        amount: '',
        network: 'trc20',
        walletAddress: '',
        email: ''
      },
      networks: [
        { value: 'trc20', text: 'TRC20' },
        { value: 'bep20', text: 'BEP20' }
      ],
      errors: {},
      status: null,
      isSubmitting: false
    };
  },
  methods: {
    validate() {
      this.errors = {};
      if (!this.formData.amount) this.errors.amount = 'Amount is required';
      if (!this.formData.walletAddress) this.errors.walletAddress = 'Wallet address is required';
      if (!this.formData.email) this.errors.email = 'Email is required';
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(this.formData.email)) {
        this.errors.email = 'Invalid email format';
      }
      return Object.keys(this.errors).length === 0;
    },
    async onSubmit() {
      if (!this.validate()) return;
      
      this.isSubmitting = true;
      this.status = null;
      
      try {
        await submitExchangeRequest(this.formData);
        this.status = {
          type: 'success',
          text: 'Please send payment to PayPal: tala.sala94@gmail.com. After payment, we will process your request within 48 hours.'
        };
        this.resetForm();
      } catch (error) {
        this.status = {
          type: 'error',
          text: error.message || 'Failed to submit request. Please try again or contact support.'
        };
      } finally {
        this.isSubmitting = false;
      }
    },
    resetForm() {
      this.formData = {
        operation: 'buy',
        amount: '',
        network: 'trc20',
        walletAddress: '',
        email: ''
      };
      this.errors = {};
    }
  }
};
</script>

<style lang="scss" scoped>
.form {
  padding: 16;
}

.input-group {
  margin-bottom: 16;
}

.label {
  color: #fbbf24;
  font-size: 14;
  margin-bottom: 4;
}

.input {
  background-color: rgba(251, 191, 36, 0.1);
  border-width: 1;
  border-color: rgba(251, 191, 36, 0.3);
  border-radius: 8;
  padding: 12;
  color: #fbbf24;
}

.dropdown {
  background-color: rgba(251, 191, 36, 0.1);
  border-width: 1;
  border-color: rgba(251, 191, 36, 0.3);
  border-radius: 8;
  padding: 12;
  color: #fbbf24;
}

.error {
  color: #ef4444;
  font-size: 12;
  margin-top: 4;
}

.info-box {
  background-color: rgba(251, 191, 36, 0.1);
  border-radius: 8;
  padding: 12;
  margin-bottom: 16;
}

.info-label {
  color: #fbbf24;
  font-size: 14;
}

.info-value {
  color: #fbbf24;
  font-weight: bold;
  font-size: 16;
}

.submit-button {
  background-color: #fbbf24;
  color: #1e293b;
  font-weight: bold;
  border-radius: 8;
  padding: 16;
  margin-top: 16;

  &:disabled {
    opacity: 0.5;
  }
}

.status-message {
  padding: 12;
  border-radius: 8;
  margin-bottom: 16;

  &.success {
    background-color: rgba(34, 197, 94, 0.1);
    color: #22c55e;
  }

  &.error {
    background-color: rgba(239, 68, 68, 0.1);
    color: #ef4444;
  }
}
</style></content>