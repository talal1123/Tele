import React from 'react';
import { Globe } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

export const LanguageToggle: React.FC = () => {
  const { language, setLanguage } = useLanguage();

  return (
    <button
      onClick={() => setLanguage(language === 'en' ? 'ar' : 'en')}
      className="flex items-center gap-2 bg-secondary-800/50 hover:bg-secondary-700/50 text-primary-400 px-4 py-2 rounded-lg transition-all duration-300"
      dir={language === 'ar' ? 'rtl' : 'ltr'}
    >
      <Globe size={18} />
      <span>{language === 'en' ? 'العربية' : 'English'}</span>
    </button>
  );
};