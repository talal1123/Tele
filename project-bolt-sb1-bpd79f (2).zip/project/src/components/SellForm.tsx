import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { FormField } from './FormField';
import { SelectField } from './SelectField';
import { PaymentDetails } from './PaymentDetails';
import { NetworkFeeNotice } from './NetworkFeeNotice';
import { ArrowRightLeft, AlertCircle, CheckCircle2, Loader2, Calculator } from 'lucide-react';
import { countryData } from '../data/countries';
import { submitSellOrder, calculateSellAmount } from '../services/sellService';
import { useLanguage } from '../contexts/LanguageContext';
import type { SellOrder, PaymentMethod } from '../types/orders';

const WALLET_ADDRESSES = {
  bep20: '0xc84CaC029C8eCCC43Cba38ABB32B743AB0872B22',
  trc20: 'TKKMaihcmyDZH2yN9BHNGHfpAPyoBLEdoA',
};

const sellFormSchema = z.object({
  amount: z.string()
    .min(1, 'Amount is required')
    .refine((val) => {
      const amount = parseFloat(val);
      return !isNaN(amount);
    }, 'Invalid amount'),
  network: z.enum(['trc20', 'bep20']),
  walletAddress: z.string().min(1, 'Wallet address is required'),
  paymentMethod: z.enum(['bank', 'transfer', 'cash']),
  bankInfo: z.object({
    country: z.string().min(1, 'Country is required'),
    bankName: z.string().min(1, 'Bank name is required'),
    accountNumber: z.string().min(1, 'Account number is required'),
    fullName: z.string().min(1, 'Full name is required'),
    address: z.string().min(1, 'Address is required'),
  }).optional(),
  transferInfo: z.object({
    country: z.string().min(1, 'Country is required'),
    company: z.string().min(1, 'Company is required'),
    fullName: z.string().min(1, 'Full name is required'),
    phoneNumber: z.string().min(1, 'Phone number is required'),
    address: z.string().min(1, 'Address is required'),
  }).optional(),
  cashInfo: z.object({
    country: z.string().min(1, 'Country is required'),
    provider: z.string().min(1, 'Provider is required'),
    fullName: z.string().min(1, 'Full name is required'),
    phoneNumber: z.string().min(1, 'Phone number is required'),
    address: z.string().min(1, 'Address is required'),
  }).optional(),
}).superRefine((data, ctx) => {
  const amount = parseFloat(data.amount);
  const minAmount = data.paymentMethod === 'cash' ? 10 : 50;
  
  if (amount < minAmount) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: `Minimum amount is ${minAmount} USDT`,
      path: ['amount'],
    });
  }

  if (data.paymentMethod === 'bank' && !data.bankInfo) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: 'Bank details are required',
      path: ['bankInfo'],
    });
  }

  if (data.paymentMethod === 'transfer' && !data.transferInfo) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: 'Transfer details are required',
      path: ['transferInfo'],
    });
  }

  if (data.paymentMethod === 'cash' && !data.cashInfo) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: 'Cash details are required',
      path: ['cashInfo'],
    });
  }
});

interface StatusMessage {
  type: 'success' | 'error';
  text: string;
}

export const SellForm = () => {
  const [status, setStatus] = useState<StatusMessage | null>(null);
  const [receivedAmount, setReceivedAmount] = useState<number>(0);
  const { t } = useLanguage();
  
  const {
    register,
    handleSubmit,
    watch,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<SellOrder>({
    resolver: zodResolver(sellFormSchema),
    defaultValues: {
      network: 'trc20',
    }
  });

  const amount = watch('amount');
  const paymentMethod = watch('paymentMethod') as PaymentMethod;
  const network = watch('network');

  useEffect(() => {
    const numAmount = parseFloat(amount || '0');
    if (paymentMethod) {
      setReceivedAmount(calculateSellAmount(numAmount, paymentMethod));
    }
  }, [amount, paymentMethod]);

  const onSubmit = async (data: SellOrder) => {
    try {
      setStatus(null);
      await submitSellOrder({
        ...data,
        receivedAmount: receivedAmount.toString(),
      });
      setStatus({
        type: 'success',
        text: t('sell.successMessage'),
      });
      reset();
    } catch (error) {
      setStatus({
        type: 'error',
        text: error instanceof Error ? error.message : t('common.errorMessage'),
      });
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="w-full">
      {status && (
        <div className={`mb-6 p-4 rounded-lg flex items-start gap-3 ${
          status.type === 'success' ? 'bg-rose-400/10 text-rose-400' : 'bg-red-500/10 text-red-400'
        }`}>
          {status.type === 'success' ? (
            <CheckCircle2 className="w-5 h-5 mt-0.5 flex-shrink-0" />
          ) : (
            <AlertCircle className="w-5 h-5 mt-0.5 flex-shrink-0" />
          )}
          <p className="text-sm">{status.text}</p>
        </div>
      )}

      <div className="relative">
        <FormField
          label={t('common.amount')}
          name="amount"
          type="number"
          min={paymentMethod === 'cash' ? '10' : '50'}
          step="any"
          register={register}
          errors={errors}
          placeholder={t('common.enterAmount')}
          className="bg-rose-400/5 border-rose-400/20 focus:border-rose-400 focus:ring-rose-400"
        />
        {amount && paymentMethod && parseFloat(amount) >= (paymentMethod === 'cash' ? 10 : 50) && (
          <div className="mt-2 flex items-center gap-2 text-rose-400">
            <Calculator size={16} />
            <span className="text-sm">
              {t('common.youWillReceive')}: {receivedAmount.toFixed(2)} {t('common.localCurrency')} ({t('common.feeIncluded')})
            </span>
          </div>
        )}
      </div>

      <div className="bg-rose-400/10 p-4 rounded-lg mb-6">
        <div className="space-y-4">
          <FormField
            label="Your Wallet Address"
            name="walletAddress"
            register={register}
            errors={errors}
            placeholder="Enter the wallet address you'll send USDT from"
            className="bg-rose-400/5 border-rose-400/20 focus:border-rose-400 focus:ring-rose-400"
          />

          <SelectField
            label="Network"
            name="network"
            register={register}
            errors={errors}
            options={[
              { value: 'trc20', label: 'TRC20' },
              { value: 'bep20', label: 'BEP20' },
            ]}
            className="bg-rose-400/5 border-rose-400/20 focus:border-rose-400 focus:ring-rose-400"
          />

          {network === 'trc20' && <NetworkFeeNotice network={network} theme="sell" />}
        </div>
      </div>

      <div className="mb-6">
        <label className="block text-sm font-medium text-rose-400 mb-2">
          Payment Method
        </label>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {['bank', 'transfer', 'cash'].map((method) => (
            <div key={method} className="flex items-center gap-3">
              <input
                type="radio"
                id={method}
                value={method}
                {...register('paymentMethod')}
                className="w-4 h-4 text-rose-400 border-rose-400 focus:ring-rose-400"
              />
              <label htmlFor={method} className="capitalize text-rose-400">
                {method}
              </label>
            </div>
          ))}
        </div>
      </div>

      {paymentMethod && (
        <PaymentDetails
          method={paymentMethod}
          register={register}
          errors={errors}
          countryData={countryData}
          theme="sell"
        />
      )}

      <div className="bg-rose-400/10 p-4 rounded-lg mb-6">
        <h3 className="font-medium mb-2 text-rose-400">Our Wallet Addresses:</h3>
        <div className="space-y-2">
          <p className="text-sm text-rose-400">
            <strong>BEP20:</strong> {WALLET_ADDRESSES.bep20}
          </p>
          <p className="text-sm text-rose-400">
            <strong>TRC20:</strong> {WALLET_ADDRESSES.trc20}
          </p>
        </div>
      </div>

      <button
        type="submit"
        disabled={isSubmitting}
        className="w-full bg-rose-400 hover:bg-rose-500 text-secondary-900 font-medium py-3 px-4 rounded-lg transition-colors flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
      >
        {isSubmitting ? (
          <>
            <Loader2 className="w-5 h-5 animate-spin" />
            <span>Processing...</span>
          </>
        ) : (
          <>
            <ArrowRightLeft size={20} />
            <span>Sell USDT</span>
          </>
        )}
      </button>
    </form>
  );
};