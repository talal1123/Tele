import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { FormField } from './FormField';
import { SelectField } from './SelectField';
import { PaymentDetails } from './PaymentDetails';
import { ArrowRightLeft, AlertCircle, CheckCircle2, Loader2 } from 'lucide-react';
import { countryData } from '../data/countries';
import { submitExchangeRequest } from '../services/api';
import type { FormData, PaymentMethod } from '../types';

const WALLET_ADDRESSES = {
  bep20: '0xc84CaC029C8eCCC43Cba38ABB32B743AB0872B22',
  trc20: 'TKKMaihcmyDZH2yN9BHNGHfpAPyoBLEdoA',
};

const formSchema = z.object({
  operation: z.enum(['buy', 'sell']),
  amount: z.string().min(1, 'Amount is required'),
  paymentMethod: z.enum(['bank', 'transfer', 'cash']).optional(),
  network: z.enum(['trc20', 'bep20']),
  walletAddress: z.string().min(1, 'Wallet address is required'),
  email: z.string().email('Invalid email address').optional(),
  bankInfo: z.object({
    country: z.string().optional(),
    accountNumber: z.string().optional(),
    fullName: z.string().optional(),
    bankName: z.string().optional(),
    address: z.string().optional(),
  }).optional(),
  transferInfo: z.object({
    country: z.string().optional(),
    company: z.string().optional(),
    fullName: z.string().optional(),
    phoneNumber: z.string().optional(),
    address: z.string().optional(),
  }).optional(),
  cashInfo: z.object({
    country: z.string().optional(),
    provider: z.string().optional(),
    phoneNumber: z.string().optional(),
    fullName: z.string().optional(),
  }).optional(),
});

interface StatusMessage {
  type: 'success' | 'error';
  text: string;
}

export const Form = () => {
  const [status, setStatus] = useState<StatusMessage | null>(null);
  const {
    register,
    handleSubmit,
    watch,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      operation: 'buy',
      network: 'trc20',
    }
  });

  const operation = watch('operation');
  const paymentMethod = watch('paymentMethod') as PaymentMethod;

  const onSubmit = async (data: FormData) => {
    try {
      setStatus(null);
      await submitExchangeRequest(data);
      
      const message = data.operation === 'buy'
        ? 'Please send payment to PayPal: tala.sala94@gmail.com. After payment, we will process your request within 48 hours.'
        : 'Your request has been received. Please send the USDT to our wallet address. The process will be completed within 48 hours.';
      
      setStatus({
        type: 'success',
        text: message,
      });
      
      reset();
    } catch (error) {
      setStatus({
        type: 'error',
        text: error instanceof Error ? error.message : 'Failed to submit request. Please try again or contact support.',
      });
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="w-full">
      {status && (
        <div className={`mb-6 p-4 rounded-lg flex items-start gap-3 ${
          status.type === 'success' ? 'bg-primary-400/10 text-primary-400' : 'bg-red-500/10 text-red-400'
        }`}>
          {status.type === 'success' ? (
            <CheckCircle2 className="w-5 h-5 mt-0.5 flex-shrink-0" />
          ) : (
            <AlertCircle className="w-5 h-5 mt-0.5 flex-shrink-0" />
          )}
          <p className="text-sm">{status.text}</p>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <div className="flex items-center gap-4">
          <input
            type="radio"
            id="buy"
            value="buy"
            {...register('operation')}
            className="w-4 h-4 text-primary-400 border-primary-400 focus:ring-primary-400"
          />
          <label htmlFor="buy" className="text-lg font-medium text-primary-400">Buy USDT</label>
        </div>
        <div className="flex items-center gap-4">
          <input
            type="radio"
            id="sell"
            value="sell"
            {...register('operation')}
            className="w-4 h-4 text-primary-400 border-primary-400 focus:ring-primary-400"
          />
          <label htmlFor="sell" className="text-lg font-medium text-primary-400">Sell USDT</label>
        </div>
      </div>

      <FormField
        label="Amount (USDT)"
        name="amount"
        type="number"
        min="1"
        step="any"
        register={register}
        errors={errors}
        placeholder="Enter amount"
      />

      {operation === 'buy' && (
        <div className="bg-primary-400/10 p-4 rounded-lg mb-6">
          <p className="text-primary-400">
            Payment available via PayPal only: <strong>tala.sala94@gmail.com</strong>
          </p>
          <div className="mt-4">
            <FormField
              label="Your Wallet Address"
              name="walletAddress"
              register={register}
              errors={errors}
              placeholder="Enter your wallet address"
            />
            <SelectField
              label="Network"
              name="network"
              register={register}
              errors={errors}
              options={[
                { value: 'trc20', label: 'TRC20' },
                { value: 'bep20', label: 'BEP20' },
              ]}
            />
            <FormField
              label="Your Email"
              name="email"
              type="email"
              register={register}
              errors={errors}
              placeholder="Enter your PayPal email"
            />
          </div>
        </div>
      )}

      {operation === 'sell' && (
        <>
          <div className="bg-primary-400/10 p-4 rounded-lg mb-6">
            <FormField
              label="Your Wallet Address"
              name="walletAddress"
              register={register}
              errors={errors}
              placeholder="Enter the wallet address you'll send USDT from"
            />
            <SelectField
              label="Network"
              name="network"
              register={register}
              errors={errors}
              options={[
                { value: 'trc20', label: 'TRC20' },
                { value: 'bep20', label: 'BEP20' },
              ]}
            />
          </div>

          <div className="mb-6">
            <label className="block text-sm font-medium text-primary-400 mb-2">
              Payment Method
            </label>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {['bank', 'transfer', 'cash'].map((method) => (
                <div key={method} className="flex items-center gap-3">
                  <input
                    type="radio"
                    id={method}
                    value={method}
                    {...register('paymentMethod')}
                    className="w-4 h-4 text-primary-400 border-primary-400 focus:ring-primary-400"
                  />
                  <label htmlFor={method} className="capitalize text-primary-400">
                    {method}
                  </label>
                </div>
              ))}
            </div>
          </div>

          {paymentMethod && (
            <PaymentDetails
              method={paymentMethod}
              register={register}
              errors={errors}
              countryData={countryData}
            />
          )}

          <div className="bg-primary-400/10 p-4 rounded-lg mb-6">
            <h3 className="font-medium mb-2 text-primary-400">Our Wallet Addresses:</h3>
            <div className="space-y-2">
              <p className="text-sm text-primary-400">
                <strong>BEP20:</strong> {WALLET_ADDRESSES.bep20}
              </p>
              <p className="text-sm text-primary-400">
                <strong>TRC20:</strong> {WALLET_ADDRESSES.trc20}
              </p>
            </div>
          </div>
        </>
      )}

      <button
        type="submit"
        disabled={isSubmitting}
        className="w-full bg-primary-400 hover:bg-primary-500 text-secondary-900 font-medium py-3 px-4 rounded-lg transition-colors flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
      >
        {isSubmitting ? (
          <>
            <Loader2 className="w-5 h-5 animate-spin" />
            <span>Processing...</span>
          </>
        ) : (
          <>
            <ArrowRightLeft size={20} />
            <span>Submit Exchange Request</span>
          </>
        )}
      </button>
    </form>
  );
};