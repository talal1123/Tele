<content><template>
  <StackLayout class="form">
    <!-- Status Message -->
    <StackLayout v-if="status" :class="['status-message', status.type]">
      <Label :text="status.text" textWrap="true" />
    </StackLayout>

    <!-- Amount Input -->
    <StackLayout class="input-group">
      <Label text="Amount (USDT)" class="label" />
      <TextField
        v-model="formData.amount"
        keyboardType="number"
        class="input"
        hint="Enter amount"
      />
      <Label v-if="errors.amount" :text="errors.amount" class="error" />
    </StackLayout>

    <!-- Wallet Address -->
    <StackLayout class="input-group">
      <Label text="Your Wallet Address" class="label" />
      <TextField
        v-model="formData.walletAddress"
        class="input"
        hint="Enter the wallet address you'll send USDT from"
      />
      <Label v-if="errors.walletAddress" :text="errors.walletAddress" class="error" />
    </StackLayout>

    <!-- Network Selection -->
    <StackLayout class="input-group">
      <Label text="Network" class="label" />
      <DropDown
        :items="networks"
        v-model="formData.network"
        class="dropdown"
      />
      <Label v-if="errors.network" :text="errors.network" class="error" />
    </StackLayout>

    <!-- Payment Method -->
    <StackLayout class="input-group">
      <Label text="Payment Method" class="label" />
      <FlexboxLayout class="payment-methods">
        <StackLayout 
          v-for="method in paymentMethods" 
          :key="method"
          class="payment-method"
          @tap="selectPaymentMethod(method)"
        >
          <Label 
            :text="method"
            :class="['payment-method-text', formData.paymentMethod === method ? 'selected' : '']"
          />
        </StackLayout>
      </FlexboxLayout>
    </StackLayout>

    <!-- Payment Details -->
    <PaymentDetails
      v-if="formData.paymentMethod"
      :method="formData.paymentMethod"
      :formData="formData"
      @update="updatePaymentDetails"
    />

    <!-- Our Wallet Addresses -->
    <StackLayout class="info-box">
      <Label text="Our Wallet Addresses:" class="info-label" />
      <Label :text="'BEP20: ' + walletAddresses.bep20" class="wallet-address" textWrap="true" />
      <Label :text="'TRC20: ' + walletAddresses.trc20" class="wallet-address" textWrap="true" />
    </StackLayout>

    <!-- Submit Button -->
    <Button
      :text="isSubmitting ? 'Processing...' : 'Sell USDT'"
      @tap="onSubmit"
      :isEnabled="!isSubmitting"
      class="submit-button"
    />
  </StackLayout>
</template>

<script>
import { submitExchangeRequest } from '../services/api';
import PaymentDetails from './PaymentDetails';

export default {
  name: 'SellForm',
  components: {
    PaymentDetails
  },
  data() {
    return {
      formData: {
        operation: 'sell',
        amount: '',
        network: 'trc20',
        walletAddress: '',
        paymentMethod: null,
        bankInfo: {},
        transferInfo: {},
        cashInfo: {}
      },
      networks: [
        { value: 'trc20', text: 'TRC20' },
        { value: 'bep20', text: 'BEP20' }
      ],
      paymentMethods: ['bank', 'transfer', 'cash'],
      walletAddresses: {
        bep20: '0xc84CaC029C8eCCC43Cba38ABB32B743AB0872B22',
        trc20: 'TKKMaihcmyDZH2yN9BHNGHfpAPyoBLEdoA'
      },
      errors: {},
      status: null,
      isSubmitting: false
    };
  },
  methods: {
    selectPaymentMethod(method) {
      this.formData.paymentMethod = method;
    },
    updatePaymentDetails(details) {
      const key = `${this.formData.paymentMethod}Info`;
      this.formData[key] = details;
    },
    validate() {
      this.errors = {};
      if (!this.formData.amount) this.errors.amount = 'Amount is required';
      if (!this.formData.walletAddress) this.errors.walletAddress = 'Wallet address is required';
      return Object.keys(this.errors).length === 0;
    },
    async onSubmit() {
      if (!this.validate()) return;
      
      this.isSubmitting = true;
      this.status = null;
      
      try {
        await submitExchangeRequest(this.formData);
        this.status = {
          type: 'success',
          text: 'Your request has been received. Please send the USDT to our wallet address. The process will be completed within 48 hours.'
        };
        this.resetForm();
      } catch (error) {
        this.status = {
          type: 'error',
          text: error.message || 'Failed to submit request. Please try again or contact support.'
        };
      } finally {
        this.isSubmitting = false;
      }
    },
    resetForm() {
      this.formData = {
        operation: 'sell',
        amount: '',
        network: 'trc20',
        walletAddress: '',
        paymentMethod: null,
        bankInfo: {},
        transferInfo: {},
        cashInfo: {}
      };
      this.errors = {};
    }
  }
};
</script>

<style lang="scss" scoped>
.form {
  padding: 16;
}

.input-group {
  margin-bottom: 16;
}

.label {
  color: #fbbf24;
  font-size: 14;
  margin-bottom: 4;
}

.input {
  background-color: rgba(251, 191, 36, 0.1);
  border-width: 1;
  border-color: rgba(251, 191, 36, 0.3);
  border-radius: 8;
  padding: 12;
  color: #fbbf24;
}

.dropdown {
  background-color: rgba(251, 191, 36, 0.1);
  border-width: 1;
  border-color: rgba(251, 191, 36, 0.3);
  border-radius: 8;
  padding: 12;
  color: #fbbf24;
}

.payment-methods {
  flex-wrap: wrap;
  justify-content: space-between;
}

.payment-method {
  flex: 1;
  margin: 4;
  padding: 12;
  background-color: rgba(251, 191, 36, 0.1);
  border-radius: 8;
  border-width: 1;
  border-color: rgba(251, 191, 36, 0.3);
}

.payment-method-text {
  color: #fbbf24;
  text-align: center;
  text-transform: capitalize;
  
  &.selected {
    font-weight: bold;
  }
}

.info-box {
  background-color: rgba(251, 191, 36, 0.1);
  border-radius: 8;
  padding: 12;
  margin: 16 0;
}

.info-label {
  color: #fbbf24;
  font-size: 14;
  margin-bottom: 8;
}

.wallet-address {
  color: #fbbf24;
  font-size: 12;
  margin-top: 4;
}

.submit-button {
  background-color: #fbbf24;
  color: #1e293b;
  font-weight: bold;
  border-radius: 8;
  padding: 16;
  margin-top: 16;

  &:disabled {
    opacity: 0.5;
  }
}

.status-message {
  padding: 12;
  border-radius: 8;
  margin-bottom: 16;

  &.success {
    background-color: rgba(34, 197, 94, 0.1);
    color: #22c55e;
  }

  &.error {
    background-color: rgba(239, 68, 68, 0.1);
    color: #ef4444;
  }
}
</style></content>