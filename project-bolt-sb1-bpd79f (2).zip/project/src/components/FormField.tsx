import React from 'react';
import { UseFormRegister, FieldValues, FieldErrors } from 'react-hook-form';

interface FormFieldProps {
  label: string;
  name: string;
  type?: string;
  register: UseFormRegister<FieldValues>;
  errors: FieldErrors;
  placeholder?: string;
  min?: string;
  step?: string;
  className?: string;
}

export const FormField: React.FC<FormFieldProps> = ({
  label,
  name,
  type = 'text',
  register,
  errors,
  placeholder,
  min,
  step,
  className,
}) => {
  return (
    <div className="mb-4">
      <label htmlFor={name} className="block text-sm font-medium mb-1.5">
        {label}
      </label>
      <input
        {...register(name)}
        type={type}
        id={name}
        placeholder={placeholder}
        min={min}
        step={step}
        className={`w-full px-4 py-3 rounded-xl focus:ring-2 transition-colors ${className}`}
      />
      {errors[name] && (
        <p className="mt-2 text-sm text-red-400 flex items-center gap-1">
          <span className="inline-block w-1 h-1 bg-red-400 rounded-full"></span>
          {errors[name]?.message as string}
        </p>
      )}
    </div>
  );
};