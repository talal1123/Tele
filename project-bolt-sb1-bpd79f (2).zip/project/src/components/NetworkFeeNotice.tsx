import React from 'react';
import { AlertCircle } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

interface NetworkFeeNoticeProps {
  network: string;
  theme?: 'buy' | 'sell';
}

export const NetworkFeeNotice: React.FC<NetworkFeeNoticeProps> = ({ network, theme = 'buy' }) => {
  const { t } = useLanguage();
  
  if (network !== 'trc20') return null;

  const themeClasses = theme === 'buy' 
    ? 'bg-emerald-400/5 border-emerald-400/10 text-emerald-400'
    : 'bg-rose-400/5 border-rose-400/10 text-rose-400';

  return (
    <div className={`flex items-start gap-2 p-3 rounded-lg border ${themeClasses} mb-4`}>
      <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
      <p className="text-sm">
        {t('common.networkFeeNotice')}
      </p>
    </div>
  );
};