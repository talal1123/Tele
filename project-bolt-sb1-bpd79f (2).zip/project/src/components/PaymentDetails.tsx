import React, { useState } from 'react';
import { UseFormRegister, FieldErrors } from 'react-hook-form';
import { FormField } from './FormField';
import { SelectField } from './SelectField';
import { MapPin } from 'lucide-react';
import type { PaymentMethod } from '../types/orders';

interface PaymentDetailsProps {
  method: PaymentMethod;
  register: UseFormRegister<any>;
  errors: FieldErrors;
  countryData: Record<string, Record<string, string[]>>;
  theme?: 'sell';
}

export const PaymentDetails: React.FC<PaymentDetailsProps> = ({
  method,
  register,
  errors,
  countryData,
  theme,
}) => {
  const [selectedCountry, setSelectedCountry] = useState<string>('');
  const countries = Object.keys(countryData[method]);
  
  const handleCountryChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setSelectedCountry(e.target.value);
  };

  const getServiceOptions = () => {
    if (!selectedCountry) return [];
    return countryData[method][selectedCountry].map(service => ({
      value: service,
      label: service
    }));
  };

  const getThemeClasses = () => {
    if (theme === 'sell') {
      return {
        container: 'bg-rose-400/5 border-rose-400/10',
        text: 'text-rose-400',
        input: 'bg-rose-400/5 border-rose-400/20 focus:border-rose-400 focus:ring-rose-400',
      };
    }
    return {
      container: 'bg-primary-400/5 border-primary-400/10',
      text: 'text-primary-400',
      input: 'bg-primary-400/5 border-primary-400/20 focus:border-primary-400 focus:ring-primary-400',
    };
  };

  const themeClasses = getThemeClasses();
  
  return (
    <div className={`card mb-6 ${themeClasses.container}`}>
      <div className="flex items-center gap-3 mb-6">
        <div className={`${themeClasses.container} p-2 rounded-lg`}>
          <MapPin className={`w-5 h-5 ${themeClasses.text}`} />
        </div>
        <h3 className={`text-lg font-medium capitalize ${themeClasses.text}`}>
          {method} Payment Details
        </h3>
      </div>
      
      <div className="mb-4">
        <label htmlFor="country" className={`block text-sm font-medium mb-1.5 ${themeClasses.text}`}>
          Country
        </label>
        <select
          {...register(`${method}Info.country`)}
          id="country"
          onChange={handleCountryChange}
          className={`w-full px-4 py-3 rounded-xl focus:ring-2 transition-colors ${themeClasses.input}`}
        >
          <option value="">Select Country</option>
          {countries.map(country => (
            <option key={country} value={country}>{country}</option>
          ))}
        </select>
        {errors[`${method}Info`]?.country && (
          <p className="mt-2 text-sm text-red-400 flex items-center gap-1">
            <span className="inline-block w-1 h-1 bg-red-400 rounded-full"></span>
            {errors[`${method}Info`]?.country?.message as string}
          </p>
        )}
      </div>

      {selectedCountry && (
        <div className="space-y-4 animate-fade-in">
          {method === 'bank' && (
            <>
              <SelectField
                label="Bank Name"
                name={`${method}Info.bankName`}
                register={register}
                errors={errors}
                options={getServiceOptions()}
                className={themeClasses.input}
              />
              <FormField
                label="Account Number"
                name={`${method}Info.accountNumber`}
                register={register}
                errors={errors}
                placeholder="Enter your account number"
                className={themeClasses.input}
              />
              <FormField
                label="Full Name"
                name={`${method}Info.fullName`}
                register={register}
                errors={errors}
                placeholder="Enter account holder's full name"
                className={themeClasses.input}
              />
              <FormField
                label="Address"
                name={`${method}Info.address`}
                register={register}
                errors={errors}
                placeholder="Enter your physical address"
                className={themeClasses.input}
              />
            </>
          )}

          {method === 'transfer' && (
            <>
              <SelectField
                label="Transfer Company"
                name={`${method}Info.company`}
                register={register}
                errors={errors}
                options={getServiceOptions()}
                className={themeClasses.input}
              />
              <FormField
                label="Full Name"
                name={`${method}Info.fullName`}
                register={register}
                errors={errors}
                placeholder="Enter recipient's full name"
                className={themeClasses.input}
              />
              <FormField
                label="Phone Number"
                name={`${method}Info.phoneNumber`}
                register={register}
                errors={errors}
                placeholder="Enter your phone number"
                className={themeClasses.input}
              />
              <FormField
                label="Address"
                name={`${method}Info.address`}
                register={register}
                errors={errors}
                placeholder="Enter your physical address"
                className={themeClasses.input}
              />
            </>
          )}

          {method === 'cash' && (
            <>
              <SelectField
                label="Cash Provider"
                name={`${method}Info.provider`}
                register={register}
                errors={errors}
                options={getServiceOptions()}
                className={themeClasses.input}
              />
              <FormField
                label="Full Name"
                name={`${method}Info.fullName`}
                register={register}
                errors={errors}
                placeholder="Enter your full name"
                className={themeClasses.input}
              />
              <FormField
                label="Phone Number"
                name={`${method}Info.phoneNumber`}
                register={register}
                errors={errors}
                placeholder="Enter your phone number"
                className={themeClasses.input}
              />
              <FormField
                label="Address"
                name={`${method}Info.address`}
                register={register}
                errors={errors}
                placeholder="Enter your physical address"
                className={themeClasses.input}
              />
            </>
          )}
        </div>
      )}
    </div>
  );
};