import React, { createContext, useContext, useState } from 'react';

type Language = 'en' | 'ar';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const translations = {
  en: {
    common: {
      amount: 'Amount (USDT)',
      enterAmount: 'Enter amount',
      youWillReceive: 'You will receive',
      feeIncluded: 'fee included',
      localCurrency: 'in local currency',
      networkFeeNotice: 'Additional 3 USDT network fee applies for TRC20 transfers',
      errorMessage: 'Failed to submit request. Please try again or contact support.'
    },
    buy: {
      title: 'Buy USDT',
      successMessage: 'Please send payment to PayPal: tala.sala94@gmail.com. After payment, we will process your request within 48 hours.'
    },
    sell: {
      title: 'Sell USDT',
      successMessage: 'Your request has been received. Please send the USDT to our wallet address. The process will be completed within 48 hours.'
    }
  },
  ar: {
    common: {
      amount: 'المبلغ (USDT)',
      enterAmount: 'أدخل المبلغ',
      youWillReceive: 'ستستلم',
      feeIncluded: 'شامل الرسوم',
      localCurrency: 'بالعملة المحلية',
      networkFeeNotice: 'رسوم شبكة إضافية 3 USDT تنطبق على تحويلات TRC20',
      errorMessage: 'فشل في تقديم الطلب. يرجى المحاولة مرة أخرى أو الاتصال بالدعم.'
    },
    buy: {
      title: 'شراء USDT',
      successMessage: 'يرجى إرسال الدفعة إلى PayPal: tala.sala94@gmail.com. بعد الدفع، سنعالج طلبك خلال 48 ساعة.'
    },
    sell: {
      title: 'بيع USDT',
      successMessage: 'تم استلام طلبك. يرجى إرسال USDT إلى عنوان محفظتنا. سيتم إكمال العملية خلال 48 ساعة.'
    }
  }
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguage] = useState<Language>('en');

  const t = (key: string): string => {
    const keys = key.split('.');
    let value: any = translations[language];
    
    for (const k of keys) {
      if (value && typeof value === 'object' && k in value) {
        value = value[k];
      } else {
        return key;
      }
    }
    
    return value as string;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}